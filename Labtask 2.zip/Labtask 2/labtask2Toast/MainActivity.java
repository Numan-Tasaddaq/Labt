package com.example.labtask2toast;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button showToastBtn = findViewById(R.id.showtoastbtn);

        showToastBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               Toast toast= Toast.makeText(MainActivity.this, "Toast Is here...", Toast.LENGTH_LONG);
               toast.setGravity(Gravity.BOTTOM,0,0);
               toast.setMargin(25,78);
                       toast.show();
            }
        });
    }
}